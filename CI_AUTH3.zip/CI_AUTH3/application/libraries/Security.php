<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
require_once(BASEPATH.'core/Security.php');

class Security extends CI_Security { }